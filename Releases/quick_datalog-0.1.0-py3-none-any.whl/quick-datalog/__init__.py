# quick_datalog/__init__.py
from .core import *

__version__ = "0.1.0"
__author__ = "huyuenshen"